How to run Internet Service Provider Management Project using PHP and MySQL

Download the zip file
Extract the file and copy ispms folder
Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)
Open PHPMyAdmin (http://localhost/phpmyadmin)
Create a database with name ispmsdb
Import ispmsdb.sql file(given inside the zip package in SQL file folder)
Run the script http://localhost/ispms  (frontend)

User Credential
Username: anujk30@gmail.com
Password: Test@123
or Register a new user

Admin Credential
Username: admin
Password: Test@123
