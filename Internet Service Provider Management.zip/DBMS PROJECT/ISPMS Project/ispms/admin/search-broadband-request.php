<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['ispmsaid']==0)) {
  header('location:logout.php');
  } else{



  ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        
        <title>Search broadband Request</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <link rel="icon" type="image/x-icon" href="assets/img/favicon.png" />
        <script data-search-pseudo-elements defer src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/feather-icons/4.28.0/feather.min.js" crossorigin="anonymous"></script>
    </head>
    <body class="nav-fixed">
        <?php include_once('includes/header.php');?>
        <div id="layoutSidenav">
           <?php include_once('includes/sidebar.php');?>
            <div id="layoutSidenav_content">
                <main>
                    <header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
                        <div class="container-xl px-4">
                            <div class="page-header-content pt-4">
                                <div class="row align-items-center justify-content-between">
                                    <div class="col-auto mt-4">
                                        <h1 class="page-header-title">
                                            <div class="page-header-icon"><i data-feather="filter"></i></div>
                                            Search broadband Request
                                        </h1>
                                        <div class="page-header-subtitle">Search broadband Request</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </header>
                    <!-- Main page content-->
                    <div class="container-xl px-4 mt-n10">
                        <div class="card mb-4">

<form method="post">
                                                        <div class="mb-3">
                                                            <label for="exampleFormControlInput1" style="padding-top: 30px;padding-left: 10px;padding-bottom: 10px;">Search by Booking Number:</label>

                                                            <input id="searchdata" type="text" name="searchdata" required="true" class="form-control" placeholder="Enter Booking Number">
                                                        </div>
                                                      
                                                        <br>
                                                        <button class="btn btn-primary me-2 my-1" type="submit"  name="search" id="submit">Search</button>
                                                    </form>
                            <?php
if(isset($_POST['search']))
{ 

$sdata=$_POST['searchdata'];
  ?>
                            <div class="card-header">Result against "<?php echo $sdata;?>" keyword</div>
                           
                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                         <tr><th>S.No</th>
                                            <th>Booking Number</th>
                                            <th>Name</th>
                                            <th>Mobile Number</th>
                                            <th>Email</th>
                                            <th>Plan Name</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr><th>S.No</th>
                                            <th>Booking Number</th>
                                            <th>Name</th>
                                            <th>Mobile Number</th>
                                            <th>Email</th>
                                            <th>Plan Name</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                       
                                        <tr><?php
$sql="SELECT tbluser.FullName,tbluser.MobileNumber,tbluser.Email,tblbroadbandplan.Plan,tblbookbplan.BookingNumber,tblbookbplan.Status,tblbookbplan.Assign,tblbookbplan.ID as bpid,tblbookbplan.BookingDate from  tblbookbplan join tbluser on tbluser.ID=tblbookbplan.UserID join tblbroadbandplan on tblbroadbandplan.ID=tblbookbplan.PlanID where tblbookbplan.BookingNumber like '$sdata%'";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $row)
{               ?>
                                            <td><?php echo htmlentities($cnt);?></td>
                                            <td><?php  echo htmlentities($row->BookingNumber);?></td>
                                        <td><?php  echo htmlentities($row->FullName);?></td>
                                             <td><?php  echo htmlentities($row->MobileNumber);?></td>
                                             <td><?php  echo htmlentities($row->Email);?></td>
                                          <td><?php  echo htmlentities($row->Plan);?></td>
                                          <?php if($row->Status==""){ ?>
                     <td><?php echo "Not Updated Yet"; ?></td>
<?php } else { ?>                  <td><?php  echo htmlentities($row->Status);?> (Assign To <?php  echo htmlentities($row->Assign);?>)
                  </td>
                  <?php } ?>               
                                            <td>
                                                <a href="view-booking-detail.php?editid=<?php echo htmlentities ($row->bpid);?>&&bookid=<?php echo htmlentities ($row->BookingNumber);?>"><i class="fa fa-eye" aria-hidden="true"></i></a>
                                            </td>
                                        </tr>
                                   <?php 
$cnt=$cnt+1;
} } else { ?>
  <tr>
    <td colspan="8"> No record found against this search</td>

  </tr>
  <?php } }?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
               <?php include_once('includes/footer.php');?>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables/datatables-simple-demo.js"></script>
    </body>
</html>
<?php } ?>